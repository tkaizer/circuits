## How To Make & Run
1. To make type: "**make**"
2. To run type : "**./boosim**"

## Notes
* A **NOT** is reffered to as **Inverter**

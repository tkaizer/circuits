# circuits
Project 5 
Collaborators: Matthew Boddewyn, Jacquelyn Moreno, Thomas Kaizer

We simulated the circuits given in the project handout, and made a method that tested each circuit on every combination of inputs. To run our program, type make and then ./boosim

